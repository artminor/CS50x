#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

//jc cs50 readabiltiy

int main(void)
{
    string text;
    //get input text from user
    text = get_string("Text: ");
    int letters = 0;
    int words = 0;
    int sentences = 0;
    int level = 0;

    //loops through index of string array
    for (int i = 0; i < strlen(text); i++)
    {
        //count if index holds a character
        if (isalpha(text[i]))
        {
            letters++;
        }

        //count if punctuation marks end of sentence
        if (text[i] == '.' || text[i] == '?' || text[i] == '!')
        {
            sentences++;
        }

        //count words by detecting spaces
        if ((text[i] != ' ' && text[i + 1] == ' ') || text[i + 1] == '\0')
        {
            words++;
        }
        if (text[i] == '\'' && text[i + 1] != ' ' && text[i + 2] != ' ')
        {
            words++;
        }

    }

    int L = letters * 100 / words;
    int S = sentences * 100 / words;

    level = round(0.0588 * L - 0.296 * S - 15.8);

    //print correspoonding grades
    if (level < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (level > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Grade %i\n", level);
    }

}