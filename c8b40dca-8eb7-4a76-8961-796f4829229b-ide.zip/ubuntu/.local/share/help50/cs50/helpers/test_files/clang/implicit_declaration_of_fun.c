int main(void) {
  int x = eprintf();
}
