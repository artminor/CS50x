int main(void) {
  if (2 == 2)
    int x = 1;
}
