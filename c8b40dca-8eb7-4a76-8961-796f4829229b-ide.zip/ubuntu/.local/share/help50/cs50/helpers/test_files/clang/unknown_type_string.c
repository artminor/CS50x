string baz;
int main(void) {
}
