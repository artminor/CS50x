#include <stdio.h>
int main(void) {
  int x[30];
  printf("%i\n", x["28"]);
}
