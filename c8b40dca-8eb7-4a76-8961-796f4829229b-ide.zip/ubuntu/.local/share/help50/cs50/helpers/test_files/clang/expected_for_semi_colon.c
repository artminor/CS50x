#include <stdio.h>

int main(void) {
  for (int i = 0, i < 28, i++) {
    printf("%d\n", i);
  }
}
