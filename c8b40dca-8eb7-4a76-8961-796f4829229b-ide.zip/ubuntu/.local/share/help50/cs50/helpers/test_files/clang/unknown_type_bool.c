bool baz;
int main(void) {
}
