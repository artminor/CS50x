int main(void) {
  int x = 12*x;
}
