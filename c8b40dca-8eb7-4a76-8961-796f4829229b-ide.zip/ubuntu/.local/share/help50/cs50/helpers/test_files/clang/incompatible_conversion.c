int main(void) {
  int x = "28";
}
