#include <stdio.h>

int main(void) {
  printf("%d %d", 27, 28, 29);
}
