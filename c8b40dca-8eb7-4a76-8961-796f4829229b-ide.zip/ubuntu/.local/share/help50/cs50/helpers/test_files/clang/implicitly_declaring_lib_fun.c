int main(void) {
  printf("hello, world!");
}
