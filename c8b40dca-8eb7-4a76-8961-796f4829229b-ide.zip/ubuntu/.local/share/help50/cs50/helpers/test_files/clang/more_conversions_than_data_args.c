#include <stdio.h>

int main(void) {
  printf("%d %d\n", 28);
}
