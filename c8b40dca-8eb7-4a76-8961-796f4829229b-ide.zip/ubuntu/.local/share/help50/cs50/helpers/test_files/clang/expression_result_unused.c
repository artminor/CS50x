int main(void) {
  int n = 1;
  n*12;
}
