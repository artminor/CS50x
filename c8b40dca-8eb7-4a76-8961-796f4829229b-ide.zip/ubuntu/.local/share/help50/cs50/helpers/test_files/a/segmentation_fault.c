int main(void) {
  int temp[1];
  temp[10000]++;
}
