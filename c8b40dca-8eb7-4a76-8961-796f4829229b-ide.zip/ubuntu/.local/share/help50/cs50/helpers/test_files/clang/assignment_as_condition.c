int main(void) {
  int x = 1;
  if (x = 3) {
    x++;
  }
}
