#include <cs50.h>
#include <stdio.h>
//jc cs50 pset1 mario more

int main(void)
{
    //initialize n and get row height
    int n;
    //row height must be between 1-8 inclusive
    do
    {
        n = get_int("Height: ");
    }
    while (n < 1 || n > 8);

    //for every row print space, then #, then two spaces, then # again, new line
    for (int row = 1; row <= n; row++)
    {
        printf("%*s", n - row, "");
        for (int i = 1; i <= row; i++)
        {
            printf("#");
        }
        printf("  ");
        for (int i = 1; i <= row; i++)
        {
            printf("#");
        }
        printf("\n");
    }
}