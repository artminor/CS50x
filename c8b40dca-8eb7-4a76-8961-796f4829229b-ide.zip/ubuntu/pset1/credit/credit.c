#include <cs50.h>
#include <stdio.h>
//jc cs50 pset1 credit

int main(void)
{
    //initialize credit card number
    long n;
    int digits = 0;
    string type = "INVALID\n";

    //row height must be between 1-8 inclusive
    do
    {
        n = get_long("Number: ");
        long num = n;
        string first = "";
        string firstTwo = "";
        while (num != 0)
        {
            num /= 10;
            ++digits;
        }

        int d[3] = {13, 15, 16};
        if(digits == 13 || digits == 16)
        {
            type = "VISA\n";
        }
        if(digits == 15)
        {
            type = "AMEX\n";
        }
        if(digits == 16)
        {
            type = "MASTERCARD\n";
        }
    }
    while (type == "INVALID\n");

    printf("%i", digits);



}