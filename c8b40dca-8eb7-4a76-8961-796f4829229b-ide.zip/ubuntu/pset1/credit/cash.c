#include <cs50.h>
#include <stdio.h>
#include<math.h>
//jc cs50 pset1 cash

int main(void)
{
    float dollars;
    //get input amount from user
    do
    {
        dollars = get_float("Cash Owed: ");
    }
    while (dollars <= 0);

    int cents = round(dollars * 100);

    int coins = 0;

    //count quaters
    while (cents >= 25)
    {
        cents = cents - 25;
        coins = coins + 1;
    }

    //count dimes
    while (cents >= 10)
    {
        cents = cents - 10;
        coins = coins + 1;
    }

    //count nickels
    while (cents >= 5)
    {
        cents = cents - 5;
        coins = coins + 1;
    }

    //add the rest of pennies
    coins = coins + cents;

    printf("%i\n", coins);
}